import tkinter as tk
import requests
import time

def getWeather(canvas):
    city = textField.get()
    api = "https://api.openweathermap.org/data/2.5/weather?q="+city+"&appid=06c921750b9a82d8f5d1294e1586276f"
    
    json_data = requests.get(api).json()
    condition = json_data['weather'][0]['main']
    temp = int(json_data['main']['temp'] - 273.15)
    min_temp = int(json_data['main']['temp_min'] - 273.15)
    max_temp = int(json_data['main']['temp_max'] - 273.15)
    pressure = json_data['main']['pressure']
    humidity = json_data['main']['humidity']
    wind = json_data['wind']['speed']
    sunrise = time.strftime('%I:%M:%S %p', time.localtime(json_data['sys']['sunrise']))
    sunset = time.strftime('%I:%M:%S %p', time.localtime(json_data['sys']['sunset']))

    # Choose an icon based on condition
    weather_icon = {
        "Clear": "☀️",
        "Clouds": "☁️",
        "Rain": "🌧️",
        "Drizzle": "🌦️",
        "Thunderstorm": "⛈️",
        "Snow": "❄️",
        "Mist": "🌫️"
    }.get(condition, "🌍")

    final_info = weather_icon + " " + condition + "\n" + str(temp) + "°C"
    final_data = (
        f"\nMin Temp: {min_temp}°C"
        f"\nMax Temp: {max_temp}°C"
        f"\nPressure: {pressure} hPa"
        f"\nHumidity: {humidity}%"
        f"\nWind Speed: {wind} m/s"
        f"\nSunrise: {sunrise}"
        f"\nSunset: {sunset}"
    )

    label1.config(text=final_info)
    label2.config(text=final_data)



canvas = tk.Tk()
canvas.geometry("650x550")
canvas.title("🌤️ Weather App")
canvas.configure(bg="#e3f2fd") 

f = ("Helvetica", 15, "bold")
t = ("Helvetica", 30, "bold")

title = tk.Label(canvas, text="🌍 Live Weather App", font=("Helvetica", 20, "bold"), bg="#e3f2fd", fg="#1565c0")
title.pack(pady=10)

textField = tk.Entry(canvas, justify='center', width=20, font=t, bg="#ffffff", relief="solid", bd=2)
textField.pack(pady=15)
textField.focus()
textField.bind('<Return>', getWeather)

label1 = tk.Label(canvas, font=t, bg="#e3f2fd", fg="#0d47a1")
label1.pack(pady=10)
label2 = tk.Label(canvas, font=f, bg="#e3f2fd", justify="left", fg="#212121")
label2.pack()

footer = tk.Label(canvas, text="Made by Darshan &   darshan &   nikhil", font=("Helvetica", 10), bg="#e3f2fd", fg="#555")
footer.pack(side="bottom", pady=100)

canvas.mainloop()
